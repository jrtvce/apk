
<?php
echo "</div>\n";
echo "    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js\"></script>\n";
echo "    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js\"></script>\n";
?>
<!DOCTYPE html>
<html>
  <head>
    <title>Mega Panel</title>
    <style>
      .main {
        border: 1px solid #4287f5;
        float: left;
        height: 180px;
        width: 500px;
        position: relative;
        text-align: center;
      }
      .column1 {
        color: #4287f5;
      }
      #bottom {
        position: absolute;
        bottom: 0;
        width: 100%;
        color: #ffffff;
        background-color: blue;
        padding: 15px 0;
      }
    </style>
  </head>
  <body>
      <div class="footerLinks">
        <ul>
         <center><li><a href="https://appsnscripts.com">Copyright © 2021 - AppsnScripts</a></center>
          </li>
        </ul>
      </div>
  </body>

  </div>
</body>

</html>